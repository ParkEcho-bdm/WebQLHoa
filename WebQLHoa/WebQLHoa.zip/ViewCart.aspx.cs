﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebQLHoa.Models;

namespace WebQLHoa
{
    public partial class ViewCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LienKetDuLieuChoGridView();
            }
        }

        private void LienKetDuLieuChoGridView()
        {
            Cart cart = (Cart)Session["CART"];
            if (cart != null)
            {
                //liên kết dữ liệu cho gvGioHang
                gvGioHang.DataSource = cart.Items;
                gvGioHang.DataBind();
            }
        }
    }
}
